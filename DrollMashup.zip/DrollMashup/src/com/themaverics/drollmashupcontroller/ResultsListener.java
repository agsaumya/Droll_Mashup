package com.themaverics.drollmashupcontroller;

import java.util.ArrayList;

import com.themaverics.drollmashup.Article;

public interface ResultsListener {
	public void onResultsSucceeded(ArrayList<Article> list);
}

package com.themaverics.drollmashupcontroller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import static java.lang.System.out;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.themaverics.drollmashup.Article;

import android.util.Log;
import android.widget.Toast;

public class GetArticle
{
	static InputStream is = null;
	static JSONObject jObj = null;
	static JSONArray JA=null;
	static JSONArray JA1=null;
	static String json = "";
	public static int success=0;
	private static String url = "http://10.136.109.233/PhpProject1/getarticle.php";
	public static ArrayList<Article> GA=new ArrayList<Article>();
	
	public GetArticle()
	{
		out.println("Inside Login");
	}

	public void SetArray(ArrayList<Article> GA)
	{
		this.GA=GA;
	}
	
	public ArrayList<Article> GetArray()
	{
		return GA;
	}
	public static String[] jsontostr(JSONArray JTemp)
	{
		
		String []temp=new String[JTemp.length()];
		for(int i=0;i<JTemp.length();i++)
		{
			try { 
				temp[i]=JTemp.getString(i);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
		return temp;
	}
	
	public static void JSONParser(JSONObject JA)
	{
		int article_id,num_of_text,num_of_image_links,sequence_count;
		String title;
		String []text;
		String []imagelinks;
		int []Sequencecount;
		
			try {
				article_id=JA.getInt("articleID");
				title=JA.getString("title");
				text=jsontostr(JA.getJSONArray("article_texts"));
				String []temp=jsontostr(JA.getJSONArray(""));
				Sequencecount=strtoint(temp);
				imagelinks=jsontostr(JA.getJSONArray("article_images"));
				num_of_text=text.length;
				num_of_image_links=imagelinks.length;
				sequence_count=Sequencecount.length;
				
				Article A=new Article(article_id, title, num_of_text, num_of_image_links, sequence_count);
				A.setTexts(text);
				A.setImageLinks(imagelinks);
				A.setSequenceOfContent(Sequencecount);
				GA.add(A);
				out.println("Text length="+num_of_text);
				out.println("image links count="+num_of_image_links);
				out.println("Sequence count"+sequence_count);
				out.println("title="+title);
				out.println("Article ID="+article_id);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
	
	public static int[] strtoint(String[] temp)
	{
		int intarray[] = new int[temp.length];
		for (int i = 0; i <temp.length; i++) {
		intarray[i] = Integer.parseInt(temp[i]);
		}
		return intarray;
		
	}
	public static void ArticleGet() {

		// REGISTER_USER
		try
		{
		DefaultHttpClient httpClient = new DefaultHttpClient();
		
		
		HttpGet httpGet = new HttpGet(url);
	      HttpResponse getResponse = httpClient.execute(httpGet);
	      HttpEntity getResponseEntity = getResponse.getEntity();
	      if (getResponseEntity != null) {
	      // String responseMessage = EntityUtils.toString(getResponseEntity);
	       //out.println("Response Message="+responseMessage);
	      }
	    Log.d("before getcontent", "test");
		
		Log.d("after getcontent", "test");
		
		
		is = getResponseEntity.getContent();
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					is, "iso-8859-1"), 8);
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			is.close();
			json = sb.toString();
			
			out.println("json =="+json);
			Log.d("jsonresponse", json);
		} catch (Exception e) {
			Log.e("Buffer Error", "Error converting result " + e.toString());
		}

		// try parse the string to a JSON object
		try {
			if(json!=null)
			//jObj = new JSONObject(json);
			JA= (new JSONObject(json)).getJSONArray("items");
			for(int i=0;i<JA.length();i++)
			{
				JSONParser((JSONObject) JA.get(i));
			}
			
			/*JSONObject JS=(JSONObject) JA.get(0);
			JA1=JS.getJSONArray("article_texts");
			
			String []temp=jsontostr(JA1);
		    
		    for(int i=0;i<temp.length;i++)
		    {
		    	out.println(temp[i]);
		    }
			
			//success = jObj.getInt("success");
			out.println("Array Length="+JA.length());*/
			
			} catch (JSONException e) {
			e.printStackTrace();
			Log.e("JSON Parser", "Error parsing data " + e.toString());
		}

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
}

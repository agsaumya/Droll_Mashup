package com.themaverics.drollmashupcontroller;

import java.util.ArrayList;

import com.themaverics.drollmashup.Article;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

public class MyAsyncTask extends AsyncTask<ArrayList<Article>, Void,ArrayList<Article>> {
	private ProgressDialog progress;
    ResultsListener listener;
    private Context context;
    private boolean flag;
    GetArticle art=new GetArticle();
    public MyAsyncTask(Context _context,boolean flag)
    {
    	this.context= _context;
    	this.flag=flag;
    	progress = new ProgressDialog(context);
		progress.setMessage("Loading...");
    }
    
    protected void onPreExecute() {
        if(flag)
        {
        	progress.show();
        }

     }
    public void setOnResultsListener(ResultsListener listener) {
        this.listener = listener;
    }

    
    protected void onPostExecute(ArrayList<Article> result) {
       listener.onResultsSucceeded(result);
       if(flag)
       {
    	   progress.dismiss();
       }

    }


	
	

	@Override
	protected ArrayList<Article> doInBackground(ArrayList<Article>... params) {
		// TODO Auto-generated method stub
		art.SetArray(params[0]);
		art.ArticleGet();
		params[0]=art.GetArray();
		return params[0];
	}

	
	


}
package com.themaverics.drollmashupcontroller;

import java.util.ArrayList;

import com.themaverics.drollmashup.Article;

import android.content.Context;

public class Model implements ResultsListener{
	public ArrayList<Article> MA=new ArrayList<Article>();
	public int cursor=0;
	public Model()
	{
		
	}
	
	public Article getArticle(Context context)
	{
		if(cursor==0)
		{
			MyAsyncTask task = new MyAsyncTask(context,true);
	  	    task.setOnResultsListener(this);
	  	    task.execute(MA);
		}
		if(cursor>=MA.size()/2)
		{
			MyAsyncTask task = new MyAsyncTask(context,false);
	  	    task.setOnResultsListener(this);
	  	    task.execute(MA);
		}
		while(MA.size() == 0){
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return MA.get(cursor++);
	}

	
	@Override
	public void onResultsSucceeded(ArrayList<Article> list) {
		// TODO Auto-generated method stub
	this.MA=list;	
	}

}

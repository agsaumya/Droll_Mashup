package com.themaverics.drollmashupcontroller;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;

import com.themaverics.commomdata.Category;
import com.themaverics.commomdata.Preferences;
import com.themaverics.drollmashup.Article;

public class Controller {
	static int prefCount = 0;
	static Preferences preferences = new Preferences();
	public static Model m = new Model();
	
	public Controller(){
		if(prefCount == 0)
			preparePreferences();
		prefCount++;
	}
	public Article getArticle(Context context){
		return m.getArticle(context);
	}
	
	public void preparePreferences(){
		List<Category> list = new ArrayList<Category>();
		list.add(new Category("Art", false));
		list.add(new Category("Health", false));
		list.add(new Category("Hobbies", true));
		list.add(new Category("Medicine", false));
		list.add(new Category("Commerce", true));
		list.add(new Category("Automobiles", false));
		list.add(new Category("Games", false));
		list.add(new Category("Technology", false));
		list.add(new Category("Food", false));
		list.add(new Category("Home", false));
		list.add(new Category("Movies", false));
		list.add(new Category("Music", false));
		list.add(new Category("Books", false));
		list.add(new Category("Travel", false));
		list.add(new Category("Sports", false));
		
		
		preferences.setCategories(list);
		preferences.setFontSize(20);
	}
	
	public Preferences getPreferences(){
		return preferences;
	}
	
	public void updatePreferences(Preferences preferences){
		System.out.println("in update preferences");
		Controller.preferences = preferences;
	}
	
	public void likesCurrentArticle(){
		
	}
	
	public void dislikesCurrentArticle(){
		
	}
	
	public boolean loginUser(String user, String pass){
		return login.loginUser(user, pass); 
	}
	
	public boolean registerUser(String user, String pass){
		return Register.registerUser(user, pass);
	}
}

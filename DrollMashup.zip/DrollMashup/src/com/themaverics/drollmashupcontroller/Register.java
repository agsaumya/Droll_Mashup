package com.themaverics.drollmashupcontroller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import static java.lang.System.out;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;
import android.widget.Toast;



public class Register {
	static InputStream is = null;
	static JSONObject jObj = null;
	static String json = "";
	public static int success=0;
	private static String url = "http://10.136.109.233/PhpProject1/registration.php";
	public Register()
	{
		out.println("Inside Login");
	}

	public static boolean registerUser(String username, String password) {

		// REGISTER_USER
		List<NameValuePair> params = new ArrayList<NameValuePair>();

		params.add(new BasicNameValuePair("username", username));
		params.add(new BasicNameValuePair("password", password));
		try
		{
		DefaultHttpClient httpClient = new DefaultHttpClient();
		
		String paramString = URLEncodedUtils.format(params, "utf-8");
		url += "?" + paramString;
		HttpGet httpGet = new HttpGet(url);
	      HttpResponse getResponse = httpClient.execute(httpGet);
	      HttpEntity getResponseEntity = getResponse.getEntity();
	      if (getResponseEntity != null) {
	      // String responseMessage = EntityUtils.toString(getResponseEntity);
	       //out.println("Response Message="+responseMessage);
	      }
	    Log.d("before getcontent", "test");
		
		Log.d("after getcontent", "test");
		
		
		is = getResponseEntity.getContent();
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					is, "iso-8859-1"), 8);
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			is.close();
			json = sb.toString();
			
			out.println("json =="+json);
			Log.d("jsonresponse", json);
		} catch (Exception e) {
			Log.e("Buffer Error", "Error converting result " + e.toString());
		}

		// try parse the string to a JSON object
		try {
			if(json!=null)
			jObj = new JSONObject(json);
			success = jObj.getInt("success");
		} catch (JSONException e) {
			e.printStackTrace();
			Log.e("JSON Parser", "Error parsing data " + e.toString());
		}

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		if(success==1)
		{
			return true;
		}
		return false;
	}
}

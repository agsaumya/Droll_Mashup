package com.themaverics.drollmashup;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;

public class ImageService extends AsyncTask<String, Integer, Bitmap> {
	private ProgressDialog progress;
	private Context context;
	ImageView imageView;
	int screenWidth;
	
	public ImageService(Context _context, ImageView _imageView, int _screenWidth){
		super();
		context = _context;
		imageView = _imageView;
		screenWidth = _screenWidth;
		progress = new ProgressDialog(context);
		progress.setMessage("Loading...");
		
	}
	
	protected void onPreExecute() {
		System.out.println("PreExecute");
		//progress.show();
	}
	
	protected void onPostExecute(Bitmap img){
		System.out.println("PostExecute");
		if(img!=null){
			if(img.getWidth() >= screenWidth){
				float newHeight = (float) (img.getHeight()*(((screenWidth - 5)*1.0)/img.getWidth()));		
				imageView.getLayoutParams().height = (int)newHeight;
			}
			imageView.setImageBitmap(img);
			ScaleAnimation a =  new ScaleAnimation(1.0f, 1.0f, 0.0f, 1.0f);
			a.setDuration(250);
			imageView.startAnimation(a);
		}
		//progress.dismiss();
	}
	@Override
	protected Bitmap doInBackground(String... imgUrl) {
		Bitmap img = null;
		InputStream is;
		// TODO Auto-generated method stub
		try {
			URL url = new URL(imgUrl[0]);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setDoInput(true);
			connection.connect();
			is = connection.getInputStream();
			img = BitmapFactory.decodeStream(is);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return img;
	}

}

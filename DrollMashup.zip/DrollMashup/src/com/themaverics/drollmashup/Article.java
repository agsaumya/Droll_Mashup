package com.themaverics.drollmashup;

public class Article {
	int articleID;
	String title;
	String[] texts;
	String[] imageLinks;
	int[] sequenceOfContent;	//stores the order in which text and images are stored.
	boolean readCheck;

	public Article(int _articleID, String _title, int numOfTexts, int numOfImageLinks, int sizeOfSequenceOfContent){
		articleID = _articleID;
		title = _title;
		texts = new String[numOfTexts];
		imageLinks = new String[numOfImageLinks];
		sequenceOfContent = new int[sizeOfSequenceOfContent];
		readCheck = false;
	}

	public int getArticleID() {
		return articleID;
	}

	public void setArticleID(int articleID) {
		this.articleID = articleID;
	}
	
	public String getTitle(){
		return title;
	}
	
	public void setTitle(String title){
		this.title = title;
	}

	public String[] getTexts() {
		return texts;
	}

	public void setTexts(String[] texts) {
		this.texts = texts;
	}

	public String[] getImageLinks() {
		return imageLinks;
	}

	public void setImageLinks(String[] imageLinks) {
		this.imageLinks = imageLinks;
	}

	public int[] getSequenceOfContent() {
		return sequenceOfContent;
	}

	public void setSequenceOfContent(int[] sequenceOfContent) {
		this.sequenceOfContent = sequenceOfContent;
	}

	public boolean isReadCheck() {
		return readCheck;
	}

	public void setReadCheck(boolean readCheck) {
		this.readCheck = readCheck;
	}
}

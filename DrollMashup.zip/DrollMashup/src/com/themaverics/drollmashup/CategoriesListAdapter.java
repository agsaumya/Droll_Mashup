package com.themaverics.drollmashup;

import java.util.List;

import com.themaverics.commomdata.Category;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

public class CategoriesListAdapter extends ArrayAdapter<Category>{
	Context context;
	List<Category> categories;

	public CategoriesListAdapter(Context context, List<Category> categories) {
		super(context, R.layout.categories_cell_layout, categories);
		this.categories = categories;
		this.context = context;
	}
	
	public View getView(int position, View convertView, ViewGroup parent){
		LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		final Category category = categories.get(position);
		View categoryView = inflater.inflate(R.layout.categories_cell_layout, parent,false);
		TextView CategoriesTextView = (TextView) categoryView.findViewById(R.id.CategoriesTextView);
		CategoriesTextView.setText(category.getCategoryName());
		final CheckBox CategoriesCheckBox = (CheckBox) categoryView.findViewById(R.id.CategoriesCheckBox);
		CategoriesCheckBox.setChecked(category.getIsSelected());
		CategoriesCheckBox.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(category.getIsSelected()){
					category.setIsSelected(false);
					CategoriesCheckBox.setChecked(category.getIsSelected());
				}else{
					category.setIsSelected(true);
					CategoriesCheckBox.setChecked(category.getIsSelected());
				}
			}
		});
		return categoryView;
	}

}

package com.themaverics.drollmashup;

import java.io.SequenceInputStream;
import java.util.ArrayList;

import com.themaverics.commomdata.ConfigClass;
import com.themaverics.drollmashup.R;
import com.themaverics.drollmashupcontroller.Controller;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.VideoView;

public class MashHome extends Activity {
	String str;
	Article article;
	Controller controller;

	TextView titleView; 
	ArrayList<TextView> textViewArray;
	ArrayList<ImageView> imageViewArray;
	VideoView videoView;
	LinearLayout DisplayArticleLinearLayout;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestFullScreen();
		setContentView(R.layout.activity_mash_home);
		
		//StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
	   	//StrictMode.setThreadPolicy(policy);
	   	
		DisplayArticleLinearLayout = (LinearLayout) findViewById(R.id.DisplayArticleLinearLayout);
		titleView = new TextView(this);
		textViewArray = new ArrayList<TextView>();
		imageViewArray = new ArrayList<ImageView>();
		
		controller = new Controller();
		article = controller.getArticle(MashHome.this);

		presentArticle(article);
		
		
		//Droll On
		ImageButton drollOn = (ImageButton) findViewById(R.id.DrollOn);
		drollOn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				article = controller.getArticle(MashHome.this);
				cleanArticleView();
				presentArticle(article);
			}
		});
		
		
		//Likes
		ImageButton lessBored = (ImageButton) findViewById(R.id.LessBored);
		lessBored.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				controller.likesCurrentArticle();
			}
		});
		
		//DisLikes
		ImageButton Boring = (ImageButton) findViewById(R.id.Boring);
		Boring.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				controller.dislikesCurrentArticle();
			}
		});
		
		//Help
		
		ImageButton helpButton = (ImageButton) findViewById(R.id.HelpButton);
		helpButton.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent helpIntent = new Intent();
				helpIntent.setClass(MashHome.this, HelpActivity.class);
				startActivity(helpIntent);
			}
		});
		
		
		//Preferences
		ImageButton PreferencesButton = (ImageButton) findViewById(R.id.PreferencesButton);
		PreferencesButton.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent i = new Intent();
				i.setClass(MashHome.this, PreferencesActivity.class);
				startActivity(i);
			}
		});
	}
	
	private void requestFullScreen(){
		
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, 
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
	}
	
	public void cleanArticleView(){
		DisplayArticleLinearLayout.removeAllViews();
		for(int i=0;i<textViewArray.size();i++)
			textViewArray.remove(i);
		for(int i=0;i<imageViewArray.size();i++)
			imageViewArray.remove(i);
	}
	
	
	public void presentArticle(Article article){
		titleView.setText(article.getTitle());
		titleView.setTextColor(Color.parseColor(getResources().getString(R.string.titleColor)));
		titleView.setTextSize(ConfigClass.sizeOfTitle);
		titleView.setTextIsSelectable(true);
		DisplayArticleLinearLayout.addView(titleView,0);
		
		for(int i=0;i<article.getTexts().length;i++){
			textViewArray.add(new TextView(this));
			textViewArray.get(i).setText(article.getTexts()[i]);
			textViewArray.get(i).setTextColor(Color.parseColor(getResources().getString(R.string.textColor)));
			textViewArray.get(i).setTextIsSelectable(true);
			textViewArray.get(i).setTextSize(ConfigClass.sizeOftext);
			
		}
		for(int i=0;i<article.getImageLinks().length;i++){
			imageViewArray.add(new ImageView(this));
		}
		
		int tCount = 0;
		int iCount = 0;
		for(int i=0;i<article.sequenceOfContent.length;i++){
			if(article.sequenceOfContent[i] == 0){
				System.out.println("text View Added" + textViewArray.get(tCount).getText());
				DisplayArticleLinearLayout.addView(textViewArray.get(tCount++),i+1);
			}else if(article.sequenceOfContent[i] == 1){
				DisplayArticleLinearLayout.addView(imageViewArray.get(iCount++),i+1);
			}
		}
		
		for(int i=0;i<article.getImageLinks().length;i++){
			ImageService imageService = new ImageService(MashHome.this, imageViewArray.get(i), getResources().getDisplayMetrics().widthPixels);
			imageService.execute(article.getImageLinks()[i]);
		}
		/*WebView w = new WebView(MashHome.this);
		//w.setBackgroundColor(Color.parseColor(getResources().getString(R.string.backgroundColor)));
		w.loadUrl("http://192.168.1.114/PhpProject1/newEmptyPHP.php?url=http://www.art.org/feed/");
		DisplayArticleLinearLayout.addView(w,article.sequenceOfContent.length);*/
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.mash_home, menu);
		return true;
	}

}

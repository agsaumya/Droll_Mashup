package com.themaverics.drollmashup;

import java.util.Iterator;

import com.themaverics.commomdata.Category;
import com.themaverics.commomdata.Preferences;
import com.themaverics.drollmashupcontroller.Controller;

import android.os.Bundle;
import android.app.Activity;
import android.app.ListActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ListView;
import android.support.v4.app.NavUtils;

public class PreferencesActivity extends Activity {
	Controller controller;
	Preferences preferences;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_preferences);
		// Show the Up button in the action bar.
		//setupActionBar();
		controller = new Controller();
		preferences = controller.getPreferences();
		
		CategoriesListAdapter categoriesListAdapter = new CategoriesListAdapter(PreferencesActivity.this, preferences.getCategories());
		ListView CategoryListView = (ListView) findViewById(R.id.CategoryListView);
		CategoryListView.setAdapter(categoriesListAdapter);
	}
	
	@Override
	protected void onStop(){
		controller.updatePreferences(preferences);
		super.onStop();
	}

	/**
	 * Set up the {@link android.app.ActionBar}.
	 */
	private void setupActionBar() {

		getActionBar().setDisplayHomeAsUpEnabled(true);

	}
}

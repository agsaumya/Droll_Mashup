package com.themaverics.commomdata;

public class Category{
	String categoryName;
	Boolean isSelected;
	
	public Category(String _categoryName, Boolean _isSelected){
		categoryName = _categoryName;
		isSelected = _isSelected;
	}
	
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public Boolean getIsSelected() {
		return isSelected;
	}
	public void setIsSelected(Boolean isSelected) {
		this.isSelected = isSelected;
	}
}


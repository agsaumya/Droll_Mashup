/**All the configuration will be stored here and will be accessed as static members*/

package com.themaverics.commomdata;

public class ConfigClass {
	public final static int sizeOfArtileList = 20;
	public static int sizeOfTitle = 25;
	public static int sizeOftext = 20;
}

package com.themaverics.commomdata;

import java.util.List;

public class Preferences {
	List <Category> Categories;
	int fontSize = 12;
	
	public List<Category> getCategories() {
		return Categories;
	}
	public void setCategories(List<Category> categories) {
		Categories = categories;
	}
	public int getFontSize() {
		return fontSize;
	}
	public void setFontSize(int fontSize) {
		this.fontSize = fontSize;
	}
}